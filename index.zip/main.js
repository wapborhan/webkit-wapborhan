$("#typed").typed({
  strings: ["Wanna See??", "Are You Ready?", "Just Wait Some Days"],
  typeSpeed: 20,
  startDelay: 0,
  backSpeed: 20,
  backDelay: 1000,
  loop: true,
  cursorChar: "|",
  contentType: "html",
});
